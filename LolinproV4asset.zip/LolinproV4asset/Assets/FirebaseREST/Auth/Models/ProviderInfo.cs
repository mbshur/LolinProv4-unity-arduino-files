namespace FirebaseREST
{
    public class ProviderInfo
    {
        public string providerId;
        public string federatedId;
    }
}