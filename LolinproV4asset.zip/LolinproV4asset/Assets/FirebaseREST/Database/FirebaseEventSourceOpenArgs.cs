using System;
namespace FirebaseREST
{
    public class FirebaseEventSourceOpenArgs : EventArgs
    {
        public FirebaseEventSourceOpenArgs()
        {

        }
    }
}