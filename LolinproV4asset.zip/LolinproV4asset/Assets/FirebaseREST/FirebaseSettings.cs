using UnityEngine;
namespace FirebaseREST
{
    public class FirebaseSettings : MonoBehaviour
    {
        public string DATABASE_URL = "https://esp-v4-default-rtdb.firebaseio.com/";
        public string WEB_API = "AIzaSyDTMhGs_ISD4WKmJrCxw35rqv-bo34ZdYI";
    }
}